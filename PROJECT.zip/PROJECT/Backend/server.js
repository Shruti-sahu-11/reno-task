const express = require("express");
const sql = require("mssql");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());//


const config={
    user: "sa",
    password: "sahu@321sahu",
    server: "LAPTOP-G5FJ0C4A",
    database: "SchoolDB",
    options: {
        trustServerCertificate:true,
        trustedConnection:false,
        enableArithAbort:true,
        instancename:"SQLEXPRESS"
    },
    port:1433
}

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log("✅ Connected to MSSQL");
    return pool;
  })
  .catch(err => {
    console.log("❌ Database connection failed!", err);
  });
  //get all schools
app.get('/school',async(req, res) => {
    try{
    const pool = await sql.connect(config);
    const data = pool.request().query('select * from school');
    data.then(res1 => {
        return res.json(res1);
    })
}
catch(err){
    console.log(err);
}
})
//test route
app.get('/',(req, res) => {
    return res.json("hii i m backend");
})

app.listen(3000, () => {
    console.log("The server has started")
})

//add new school
app.post('/school', async(req, res) => {
    try{
        const {name, address, city, state, contact, image, email_id} = req.body;
        if(!name || !address || !city || !state || !contact || !image || !email_id)
        {
            return  res.status(400).json({ 
                message: "All fields are required" 
            });
        }
            const pool = await poolPromise;
            const data = await pool
            .request()
            .input("name", sql.VarChar, name)
            .input("address", sql.VarChar, address)
            .input("city", sql.VarChar, city)
            .input("state", sql.VarChar, state)
            .input("contact", sql.BigInt, contact)
            .input("image", sql.VarChar, image)
            .input("email_id", sql.VarChar, email_id)
            .query('INSERT INTO school(name, address, city, state, contact, image, email_id) VALUES (@name, @address, @city, @state, @contact, @image, @email_id)');
            res.status(200).json(data.rowsAffected);
    }
    catch(err){
    res.status(500).json(err.message);
    }
})

//udate existing schools
app.put('/school/:id', async(req, res) => {
    try{
        const {id} = req.params;
        const {name, address, city, state, contact, image, email_id} = req.body;
        if(!name || !address || !city || !state || !contact || !image || !email_id)
        {
            return  res.status(400).json({ 
                message: "All fields are required" 
            });
        }
            const pool = await poolPromise;
            const data = await pool
            .request()
            .input("id", sql.Int, id)
            .input("name", sql.VarChar, name)
            .input("address", sql.VarChar, address)
            .input("city", sql.VarChar, city)
            .input("state", sql.VarChar, state)
            .input("contact", sql.BigInt, contact)
            .input("image", sql.VarChar, image)
            .input("email_id", sql.VarChar, email_id)
            .query('UPDATE school SET name=@name, address=@address, city=@city, state=@state, contact=@contact, image=@image, email_id=@email_id WHERE id=@id');
            res.status(200).json(data.rowsAffected);
    }
    catch(err){
    res.status(500).json(err.message);
    }
}) 
//delete school by id
app.delete('/school/:id', async(req, res) => {
    try{
        const {id} = req.params;
        if(isNaN(id))
        {
            return  res.status(400).json({ 
                message: "All fields are required" 
            });
        }
            const pool = await poolPromise;
            const data = await pool
            .request()
            .input("id", sql.Int, id)
            .query('DELETE FROM school WHERE id=@id');
            console.log(data);
            res.status(200).json(data.rowsAffected);
    }
    catch(err){
    res.status(500).json(err.message);
    }
})